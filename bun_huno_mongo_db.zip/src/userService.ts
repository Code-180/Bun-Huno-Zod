//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//Import
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
import { z } from 'zod';
import { Hono } from 'hono';
import { zValidator } from '@hono/zod-validator'
//+++++++++++++++++++++++++++++++++++++++++++++
const app = new Hono();
//+++++++++++++++++++++++++++++++++++++++++++
import db from "../db/index";
//+++++++++++++++++++++++++++++++++++++++++++
const schemaCreate = z.object({
    name: z.string(),
    email: z.string().email(),
    phone: z.number().nonnegative(),
})
//+++++++++++++++++++++++++++++++++++++++++++
app.post('create-user', zValidator('json', schemaCreate, async (result, c) => {
    let resData: any = {
        status: false,
        r: {},
        message: ''
    }
    if (!result.success) {
        resData.status = false;
        resData.message = result.error;
        return c.json(resData, 200)
    } else {
        try {
            const body = await c.req.json();
            //+++++++++++++++++++++++++++++++++++++++++
            const createOBJ = await new db.userModel(body).save();
            //+++++++++++++++++++++++++++++++++++++++++
            resData.r = createOBJ;
            //+++++++++++++++++++++++++++++++++++++++++
            resData.status = true;
            resData.message = "Created Successfully";
            return c.json(resData, 200)
        } catch (e: any) {
            //+++++++++++++++++++++++++++++++++++++++++
            //console.log(e);
            //+++++++++++++++++++++++++++++++++++++++++
            resData.status = false;
            resData.message = 'Error!!';
            resData.data = JSON.stringify(e);
            return c.json(resData, 200)
        }
    }
}))
//+++++++++++++++++++++++++++++++++++++++++++
const schemaUpdate = z.object({
    _id: z.string(),
    name: z.string(),
    email: z.string().email(),
    phone: z.number().nonnegative(),
})
//+++++++++++++++++++++++++++++++++++++++++++
app.post('update-user', zValidator('json', schemaUpdate, async (result, c) => {
    let resData: any = {
        status: false,
        r: {},
        message: ''
    }
    if (!result.success) {
        resData.status = false;
        resData.message = result.error;
        return c.json(resData, 200)
    } else {
        try {
            const body = await c.req.json();
            //+++++++++++++++++++++++++++++++++++++++++
            const updateOBJ = await db.userModel.findByIdAndUpdate(body._id, body, {
                returnDocument: "after",
            });
            //+++++++++++++++++++++++++++++++++++++++++
            resData.r = updateOBJ;
            //+++++++++++++++++++++++++++++++++++++++++
            resData.status = true;
            resData.message = "Updated Successfully";
            return c.json(resData, 200)
        } catch (e: any) {
            //+++++++++++++++++++++++++++++++++++++++++
            //console.log(e);
            //+++++++++++++++++++++++++++++++++++++++++
            resData.status = false;
            resData.message = 'Error!!';
            resData.data = JSON.stringify(e);
            return c.json(resData, 200)
        }
    }
}))
//+++++++++++++++++++++++++++++++++++++++++++
app.get('list-user', async (c) => {
    let resData: any = {
        status: false,
        r: {},
        message: ''
    }
    if (!c) {
        resData.status = false;
        //resData.message = result.error;
        return c.json(resData, 200)
    } else {
        try {
            //+++++++++++++++++++++++++++++++++++++++++
            let pageSize = 10;
            //+++++++++++++++++++++++++++++++++++++++++
            // if (c.req.query('pageSize')) {
            //     const pageSizeQuery: any = c.req.query('pageSize');
            //     pageSize = parseInt(pageSizeQuery) || 10;
            // }
            //+++++++++++++++++++++++++++++++++++++++++
            let pageNumber = 1;
            //+++++++++++++++++++++++++++++++++++++++++
            // if (c.req.query('pageNumber')) {
            //     const pageNumberQuery: any = c.req.query('pageNumber');
            //     pageNumber = parseInt(pageNumberQuery) || 1;
            // }
            //+++++++++++++++++++++++++++++++++++++++++
            let limit = (pageSize * pageNumber);
            let offset = (pageSize * (pageNumber - 1));
            //+++++++++++++++++++++++++++++++++++++++++
            resData.r = await db.userModel.find().sort({ createdAt: "descending" }).skip(offset).limit(pageSize);
            resData.count = await db.userModel.countDocuments();
            //+++++++++++++++++++++++++++++++++++++++++
            resData.status = true;
            resData.message = "List";
            return c.json(resData);
        } catch (e: any) {
            //+++++++++++++++++++++++++++++++++++++++++
            console.log(e);
            //+++++++++++++++++++++++++++++++++++++++++
            resData.status = false;
            resData.message = 'Error!!';
            resData.data = JSON.stringify(e);
            return c.json(resData, 200)
        }
    }
})
//+++++++++++++++++++++++++++++++++++++++++++
const schemaSingle = z.object({
    _id: z.string(),
})
//+++++++++++++++++++++++++++++++++++++++++++
app.post('single-user', zValidator('json', schemaSingle, async (result, c) => {
    let resData: any = {
        status: false,
        r: {},
        message: ''
    }
    if (!result.success) {
        resData.status = false;
        resData.message = result.error;
        return c.json(resData, 200)
    } else {
        try {
             const body = await c.req.json();
            //+++++++++++++++++++++++++++++++++++++++++
            resData.r = await db.userModel.findById(body._id);
            //+++++++++++++++++++++++++++++++++++++++++
            resData.status = true;
            resData.message = "Single";
            return c.json(resData, 200)
        } catch (e: any) {
            //+++++++++++++++++++++++++++++++++++++++++
            //console.log(e);
            //+++++++++++++++++++++++++++++++++++++++++
            resData.status = false;
            resData.message = 'Error!!';
            resData.data = JSON.stringify(e);
            return c.json(resData, 200)
        }
    }
}))
//+++++++++++++++++++++++++++++++++++++++++++
const schemaDelete = z.object({
    _id: z.string(),
})
//+++++++++++++++++++++++++++++++++++++++++++
app.post('destroy-user', zValidator('json', schemaDelete, async (result, c) => {
    let resData: any = {
        status: false,
        r: {},
        message: ''
    }
    if (!result.success) {
        resData.status = false;
        resData.message = result.error;
        return c.json(resData, 200)
    } else {
        try {
            const body = await c.req.json();
            //+++++++++++++++++++++++++++++++++++++++++
            resData.r = await db.userModel.findByIdAndDelete(body._id);
            //+++++++++++++++++++++++++++++++++++++++++
            resData.status = true;
            resData.message = "Destroy";
            return c.json(resData, 200)
        } catch (e: any) {
            //+++++++++++++++++++++++++++++++++++++++++
            //console.log(e);
            //+++++++++++++++++++++++++++++++++++++++++
            resData.status = false;
            resData.message = 'Error!!';
            resData.data = JSON.stringify(e);
            return c.json(resData, 200)
        }
    }
}))
//+++++++++++++++++++++++++++++++++++++++++++++
export default app;
//+++++++++++++++++++++++++++++++++++++++++++++
