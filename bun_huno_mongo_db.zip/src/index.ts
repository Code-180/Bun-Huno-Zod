import { z } from 'zod';
import { Hono } from 'hono';
import { zValidator } from '@hono/zod-validator';
import { default as mongoose } from "mongoose";
//+++++++++++++++++++++++++++++++++++++++++++++
import user from './userService';
//+++++++++++++++++++++++++++++++++++++++++++++
const app = new Hono()
//+++++++++++++++++++++++++++++++++++++++++++++
// MongoDB Connection START
//+++++++++++++++++++++++++++++++++++++++++++++
const mongosCon: any = process.env.DB_CONNECTION_STRING;
//+++++++++++++++++++++++++++++++++++++++++++++
mongoose.connect(mongosCon)
  .then(() => {
    console.log("Database Connection Successfull!")
  })
  .catch((e) => {
    console.log(e);
    console.log("Database Connection Failed!")
  });
//+++++++++++++++++++++++++++++++++++++++++++++
app.route('api/user/', user);
//+++++++++++++++++++++++++++++++++++++++++++
// START THE SERVER
//+++++++++++++++++++++++++++++++++++++++++++
export default {
  port: 3000,
  fetch: app.fetch,
} 
